import java.util.Scanner;
import java.util.Random;

public class  main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        String userChoice, computerChoice = "";
        int computerNumber;
        
        while (true) {
            System.out.println("Enter rock, paper, or scissors (or type 'exit' to quit): ");
            userChoice = scanner.nextLine().toLowerCase();
            
            if (userChoice.equals("exit")) {
                System.out.println("Thanks for playing!");
                break;
            }
            
            // Check for valid input
            if (!userChoice.equals("rock") && !userChoice.equals("paper") && !userChoice.equals("scissors")) {
                System.out.println("Invalid choice, please enter rock, paper, or scissors.");
                continue;  //prompt the user again
            }
            
            // Generate computer's random choice
            computerNumber = random.nextInt(3);  // Generates a number between 0 and 2
            if (computerNumber == 0) {
                computerChoice = "rock";
            } else if (computerNumber == 1) {
                computerChoice = "paper";
            } else if (computerNumber == 2) {
                computerChoice = "scissors";
            }
            
            System.out.println("Computer chose: " + computerChoice);
            
            // Determine the winner
            if (userChoice.equals("rock")) {
                if (computerChoice.equals("rock")) {
                    System.out.println("It's a tie!");
                } else if (computerChoice.equals("paper")) {
                    System.out.println("Computer wins!");
                } else {
                    System.out.println("You win!");
                }
            } else if (userChoice.equals("paper")) {
                if (computerChoice.equals("rock")) {
                    System.out.println("You win!");
                } else if (computerChoice.equals("paper")) {
                    System.out.println("It's a tie!");
                } else {
                    System.out.println("Computer wins!");
                }
            } else if (userChoice.equals("scissors")) {
                if (computerChoice.equals("rock")) {
                    System.out.println("Computer wins!");
                } else if (computerChoice.equals("paper")) {
                    System.out.println("You win!");
                } else {
                    System.out.println("It's a tie!");
                }
            }
            
            System.out.println(); //spacing
        }
        
        scanner.close();
    }
}

